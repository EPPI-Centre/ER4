'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2008
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System.Collections.Generic
Imports System.Configuration
Imports System.Globalization
Imports System.Collections.Specialized
Imports System.Web.Security
Imports System
Imports System.Web
Imports System.Data.SqlClient
Imports System.Data
Imports System.Data.Sql
Imports DotNetNuke.Common
Imports DotNetNuke.Common.Utilities
Imports DotNetNuke.Entities.Portals
Imports DotNetNuke.Entities.Users
Imports DotNetNuke.Entities.Profile
Imports DotNetNuke.Framework.Providers
Imports DotNetNuke.Security.Membership.Data
Imports DotNetNuke.Security.Membership
Imports DotNetNuke.Security.Roles
Imports DotNetNuke.Services.Exceptions
Imports DotNetNuke.Entities.Modules
'Imports DotNetNuke.Security.Membership
Imports DotNetNuke.Services.Authentication
Imports DotNetNuke.UI.Skins.Controls.ModuleMessage
Imports DotNetNuke.UI.WebControls
'Imports DotNetNuke.Common.Utilities
'Imports DotNetNuke.Common
'Imports DotNetNuke.Entities.Users

Namespace DotNetNuke.Modules.Admin.Authentication.EPPI

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The Login AuthenticationLoginBase is used to provide a login for a registered user
    ''' portal.
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	9/24/2004	Updated to reflect design changes for Help, 508 support
    '''                       and localisation
    '''     [cnurse]    08/07/2007  Ported to new Authentication Framework
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Partial Class Login
        Inherits AuthenticationLoginBase

#Region "Protected Properties"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets whether the Captcha control is used to validate the login
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	03/17/2006  Created
        '''     [cnurse]    07/03/2007  Moved from Sign.ascx.vb
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected ReadOnly Property UseCaptcha() As Boolean
            Get
                Return DotNetNuke.Services.Authentication.EPPI.AuthenticationConfig.GetConfig(PortalId).UseCaptcha
            End Get
        End Property

#End Region

#Region "Public Properties"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Check if the Auth System is Enabled (for the Portal)
        ''' </summary>
        ''' <remarks></remarks>
        ''' <history>
        ''' 	[cnurse]	07/04/2007	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides ReadOnly Property Enabled() As Boolean
            Get
                Return DotNetNuke.Services.Authentication.EPPI.AuthenticationConfig.GetConfig(PortalId).Enabled
            End Get
        End Property
        Public aEMP As EPPIMembershipProvider
        Public aDUser As UserInfo
#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Load runs when the control is loaded
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/8/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            DotNetNuke.UI.Utilities.ClientAPI.RegisterKeyCapture(Me.Parent, Me.cmdLogin, Asc(vbCr))

            If Not Request.IsAuthenticated Then
                If Page.IsPostBack = False Then
                    Try
                        If Not Request.QueryString("username") Is Nothing Then
                            txtUsername.Text = Request.QueryString("username")
                        End If
                        If Not Request.QueryString("verificationcode") Is Nothing Then
                            'If PortalSettings.UserRegistration = PortalRegistrationType.VerifiedRegistration Then
                            '    'Display Verification Rows 
                            '    rowVerification1.Visible = True
                            '    rowVerification2.Visible = True
                            '    txtVerification.Text = Request.QueryString("verificationcode")
                            'End If
                        End If

                    Catch
                        'control not there 
                    End Try
                End If

                txtPassword.Attributes.Add("value", txtPassword.Text)

                Try
                    If String.IsNullOrEmpty(txtUsername.Text) Then
                        'SetFormFocus(txtUsername)
                    Else
                        'SetFormFocus(txtPassword)
                    End If
                Catch
                    'Not sure why this Try/Catch may be necessary, logic was there in old setFormFocus location stating the following
                    'control not there or error setting focus
                End Try
            End If

            trCaptcha1.Visible = UseCaptcha
            trCaptcha2.Visible = UseCaptcha

            If UseCaptcha Then
                ctlCaptcha.ErrorMessage = DotNetNuke.Services.Localization.Localization.GetString("InvalidCaptcha", DotNetNuke.Services.Localization.Localization.SharedResourceFile)
                ctlCaptcha.Text = DotNetNuke.Services.Localization.Localization.GetString("CaptchaText", DotNetNuke.Services.Localization.Localization.SharedResourceFile)
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdLogin_Click runs when the login button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/24/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        '''     [cnurse]    12/11/2005  Updated to reflect abstraction of Membership
        '''     [cnurse]    07/03/2007  Moved from Sign.ascx.vb
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdLogin_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdLogin.Click

            If (UseCaptcha And ctlCaptcha.IsValid) OrElse (Not UseCaptcha) Then
                Dim aEMP As EPPIMembershipProvider = New EPPIMembershipProvider()
                Dim loginStatus As UserLoginStatus = UserLoginStatus.LOGIN_FAILURE
                Dim objUser As UserInfo = aEMP.UserLogin(PortalId, txtUsername.Text, txtPassword.Text, txtVerification.Text, loginStatus)
                'Dim objUser As UserInfo = DotNetNuke.Security.Membership.EPPIMembershipProvider.Instance.UserLogin(PortalId, txtUsername.Text, txtPassword.Text, txtVerification.Text, loginStatus)
                'Dim objUser As UserInfo = UserController.ValidateUser(PortalId, txtUsername.Text, txtPassword.Text, "DNN", txtVerification.Text, PortalSettings.PortalName, IPAddress, loginStatus)
                Dim authenticated As Boolean = Null.NullBoolean
                Dim message As String = Null.NullString


                If loginStatus = UserLoginStatus.LOGIN_USERNOTAPPROVED Then
                    'Check if its the first time logging in to a verified site
                    If PortalSettings.UserRegistration = PortalRegistrationType.VerifiedRegistration Then
                        If Not rowVerification1.Visible Then
                            'Display Verification Rows so User can enter verification code
                            rowVerification1.Visible = True
                            rowVerification2.Visible = True
                            message = "EnterCode"
                        Else
                            If txtVerification.Text <> "" Then
                                message = "InvalidCode"
                            Else
                                message = "EnterCode"
                            End If
                        End If
                    Else
                        message = "UserNotAuthorized"
                    End If
                ElseIf objUser.Email = "NOTHING!" Then
                    loginStatus = UserLoginStatus.LOGIN_USERNOTAPPROVED
                    message = "To use the Support Fourms of EppiReviewer4 you need to add a valid e-Mail Address to your account."
                Else
                    authenticated = (loginStatus <> UserLoginStatus.LOGIN_FAILURE)
                End If

                'Raise UserAuthenticated Event
                Dim eventArgs As UserAuthenticatedEventArgs = New UserAuthenticatedEventArgs(objUser, txtUsername.Text, loginStatus, "EPPIMembershipProvider")
                eventArgs.Authenticated = authenticated
                eventArgs.Message = message
                OnUserAuthenticated(eventArgs)
            End If

        End Sub


#End Region

    End Class

End Namespace
'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2008
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'


Namespace DotNetNuke.Security.Membership

    ''' -----------------------------------------------------------------------------
    ''' Project:    DotNetNuke
    ''' Namespace:  DotNetNuke.Security.Membership
    ''' Class:      EngageMembershipProvider
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The EngageMembershipProvider overrides the default MembershipProvider to provide
    ''' an Engage Membership implementation
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    '''     [hkenuam]	10/05/2008	created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class EPPIMembershipProvider
        Inherits DotNetNuke.Security.Membership.MembershipProvider

        'Dim service As New AuthenticationSite.WebService

#Region "Private Shared Members"

        Private Shared dataProvider As DataProvider = dataProvider.Instance()

#End Region

#Region "Private Methods"

        Private Function AutoUnlockUser(ByVal remoteUser As RemoteSystemUser) As Boolean
            Dim intTimeout As Integer = Null.NullInteger
            If Not HostSettings("AutoAccountUnlockDuration") Is Nothing Then
                Dim strTimeout As String = Convert.ToString(HostSettings("AutoAccountUnlockDuration"))
                If Not String.IsNullOrEmpty(strTimeout) Then
                    intTimeout = Convert.ToInt32(strTimeout)
                End If
            End If
            If intTimeout <> 0 Then
                If intTimeout = Null.NullInteger Then
                    intTimeout = 10
                End If
                If remoteUser.LastLockoutDate < Date.Now.AddMinutes(-1 * intTimeout) Then
                    'Unlock user in Data Store
                    If remoteUser.UnlockUser() Then
                        Return True
                    End If
                End If
            End If

            Return False

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' CreateDNNUser persists the DNN User information to the Database
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="user">The user to persist to the Data Store.</param>
        ''' <returns>The UserId of the newly created user.</returns>
        ''' <history>
        '''     [cnurse]	12/13/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function CreateDNNUser(ByRef user As UserInfo) As UserCreateStatus

            Dim objSecurity As New PortalSecurity
            Dim userName As String = objSecurity.InputFilter(user.Username, PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoAngleBrackets Or PortalSecurity.FilterFlag.NoMarkup)
            Dim email As String = objSecurity.InputFilter(user.Email, PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoAngleBrackets Or PortalSecurity.FilterFlag.NoMarkup)
            Dim lastName As String = objSecurity.InputFilter(user.LastName, PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoAngleBrackets Or PortalSecurity.FilterFlag.NoMarkup)
            Dim firstName As String = objSecurity.InputFilter(user.FirstName, PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoAngleBrackets Or PortalSecurity.FilterFlag.NoMarkup)
            Dim createStatus As UserCreateStatus = UserCreateStatus.Success
            Dim displayName As String = objSecurity.InputFilter(user.DisplayName, PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoAngleBrackets Or PortalSecurity.FilterFlag.NoMarkup)
            Dim updatePassword As Boolean = user.Membership.UpdatePassword
            Dim isApproved As Boolean = user.Membership.Approved

            Try
                user.UserID = CType(dataProvider.AddUser(user.PortalID, userName, firstName, lastName, user.AffiliateID, user.IsSuperUser, email, displayName, updatePassword, isApproved), Integer)
            Catch ex As Exception
                'Clear User (duplicate User information)
                user = Nothing
                createStatus = UserCreateStatus.ProviderError
            End Try

            Return createStatus

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' CreateMemberhipUser persists the User as an AspNet MembershipUser to the AspNet
        ''' Data Store
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="user">The user to persist to the Data Store.</param>
        ''' <returns>A UserCreateStatus enumeration indicating success or reason for failure.</returns>
        ''' <history>
        '''     [cnurse]	12/13/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function CreateMemberhipUser(ByVal user As UserInfo) As UserCreateStatus

            Dim objSecurity As New PortalSecurity
            Dim userName As String = objSecurity.InputFilter(user.Username, PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoAngleBrackets Or PortalSecurity.FilterFlag.NoMarkup)
            Dim email As String = objSecurity.InputFilter(user.Email, PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoAngleBrackets Or PortalSecurity.FilterFlag.NoMarkup)
            Dim objStatus As System.Web.Security.MembershipCreateStatus = System.Web.Security.MembershipCreateStatus.Success

            Dim remoteUser As RemoteSystemUser

            If MembershipProviderConfig.RequiresQuestionAndAnswer Then
                remoteUser = RemoteSystemUser.CreateUser(userName, user.Membership.Password, email, user.Membership.PasswordQuestion, user.Membership.PasswordAnswer, True, objStatus)
            Else
                remoteUser = RemoteSystemUser.CreateUser(userName, user.Membership.Password, email, Nothing, Nothing, True, objStatus)
            End If

            Dim createStatus As UserCreateStatus = UserCreateStatus.Success
            Select Case objStatus
                Case System.Web.Security.MembershipCreateStatus.DuplicateEmail
                    createStatus = UserCreateStatus.DuplicateEmail
                Case System.Web.Security.MembershipCreateStatus.DuplicateProviderUserKey
                    createStatus = UserCreateStatus.DuplicateProviderUserKey
                Case System.Web.Security.MembershipCreateStatus.DuplicateUserName
                    createStatus = UserCreateStatus.DuplicateUserName
                Case System.Web.Security.MembershipCreateStatus.InvalidAnswer
                    createStatus = UserCreateStatus.InvalidAnswer
                Case System.Web.Security.MembershipCreateStatus.InvalidEmail
                    createStatus = UserCreateStatus.InvalidEmail
                Case System.Web.Security.MembershipCreateStatus.InvalidPassword
                    createStatus = UserCreateStatus.InvalidPassword
                Case System.Web.Security.MembershipCreateStatus.InvalidProviderUserKey
                    createStatus = UserCreateStatus.InvalidProviderUserKey
                Case System.Web.Security.MembershipCreateStatus.InvalidQuestion
                    createStatus = UserCreateStatus.InvalidQuestion
                Case System.Web.Security.MembershipCreateStatus.InvalidUserName
                    createStatus = UserCreateStatus.InvalidUserName
                Case System.Web.Security.MembershipCreateStatus.ProviderError
                    createStatus = UserCreateStatus.ProviderError
                Case System.Web.Security.MembershipCreateStatus.UserRejected
                    createStatus = UserCreateStatus.UserRejected
            End Select

            Return createStatus

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' DeleteMembershipUser deletes the User as an AspNet MembershipUser from the AspNet
        ''' Data Store
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="user">The user to delete from the Data Store.</param>
        ''' <returns>A Boolean indicating success or failure.</returns>
        ''' <history>
        '''     [cnurse]	12/22/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function DeleteMembershipUser(ByVal user As UserInfo) As Boolean
            Dim retValue As Boolean = True
            Try
                RemoteSystemUser.DeleteUser(user.Username)
            Catch ex As Exception
                retValue = False
            End Try
            Return retValue
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' FillUserCollection fills an ArrayList from a collection Asp.Net MembershipUsers
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="portalId">The Id of the Portal</param>
        ''' <param name="dr">The data reader corresponding to the User.</param>
        ''' <param name="isHydrated">A flag that determines whether the user is hydrated.</param>
        ''' <returns>An ArrayList of UserInfo objects.</returns>
        ''' <history>
        '''     [cnurse]	03/30/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Overloads Function FillUserCollection(ByVal portalId As Integer, ByVal dr As IDataReader, ByVal ishydrated As Boolean, ByRef totalRecords As Integer) As ArrayList
            'Note:  the DataReader returned from this method should contain 2 result sets.  The first set
            '       contains the TotalRecords, that satisfy the filter, the second contains the page
            '       of data

            Dim arrUsers As New ArrayList
            Try
                Dim obj As UserInfo
                While dr.Read
                    ' fill business object
                    obj = FillUserInfo(portalId, dr, ishydrated, False)
                    ' add to collection
                    arrUsers.Add(obj)
                End While

                'Get the next result (containing the total)
                Dim nextResult As Boolean = dr.NextResult()

                'Get the total no of records from the second result
                totalRecords = GetTotalRecords(dr)

            Catch exc As Exception
                LogException(exc)
            Finally
                ' close datareader
                If Not dr Is Nothing Then
                    dr.Close()
                End If
            End Try

            Return arrUsers

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' FillUserCollection fills an ArrayList from a collection Asp.Net MembershipUsers
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="portalId">The Id of the Portal</param>
        ''' <param name="dr">The data reader corresponding to the User.</param>
        ''' <param name="isHydrated">A flag that determines whether the user is hydrated.</param>
        ''' <returns>An ArrayList of UserInfo objects.</returns>
        ''' <history>
        '''     [cnurse]	06/15/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Overloads Function FillUserCollection(ByVal portalId As Integer, ByVal dr As IDataReader, ByVal ishydrated As Boolean) As ArrayList
            'Note:  the DataReader returned from this method should contain 2 result sets.  The first set
            '       contains the TotalRecords, that satisfy the filter, the second contains the page
            '       of data

            Dim arrUsers As New ArrayList
            Try
                Dim obj As UserInfo
                While dr.Read
                    ' fill business object
                    obj = FillUserInfo(portalId, dr, ishydrated, False)
                    ' add to collection
                    arrUsers.Add(obj)
                End While
            Catch exc As Exception
                LogException(exc)
            Finally
                ' close datareader
                If Not dr Is Nothing Then
                    dr.Close()
                End If
            End Try

            Return arrUsers

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' FillUserInfo fills a User Info object from a data reader
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="portalId">The Id of the Portal</param>
        ''' <param name="dr">The data reader corresponding to the User.</param>
        ''' <param name="isHydrated">A flag that determines whether the user is hydrated.</param>
        ''' <param name="CheckForOpenDataReader">Flag to determine whether to chcek if the datareader is open</param>
        ''' <returns>The User as a UserInfo object</returns>
        ''' <history>
        '''     [cnurse]	12/13/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function FillUserInfo(ByVal portalId As Integer, ByVal dr As IDataReader, ByVal isHydrated As Boolean, ByVal CheckForOpenDataReader As Boolean) As UserInfo

            Dim objUserInfo As UserInfo = Nothing
            Dim userName As String = Null.NullString
            Dim email As String = Null.NullString
            Dim updatePassword As Boolean
            Dim isApproved As Boolean

            Try
                ' read datareader
                Dim bContinue As Boolean = True

                If CheckForOpenDataReader Then
                    bContinue = False
                    If dr.Read Then
                        bContinue = True
                    End If
                End If
                If bContinue Then
                    objUserInfo = New UserInfo
                    objUserInfo.PortalID = portalId
                    objUserInfo.IsSuperUser = Convert.ToBoolean(dr("IsSuperUser"))
                    objUserInfo.UserID = Convert.ToInt32(dr("UserID"))
                    objUserInfo.FirstName = Convert.ToString(dr("FirstName"))
                    objUserInfo.LastName = Convert.ToString(dr("LastName"))
                    Try
                        objUserInfo.DisplayName = Convert.ToString(dr("DisplayName"))
                    Catch
                    End Try
                    Try
                        objUserInfo.AffiliateID = Convert.ToInt32(Null.SetNull(dr("AffiliateID"), objUserInfo.AffiliateID))
                    Catch
                    End Try

                    'store username and email in local variables for later use
                    'as assigning them now will trigger a GetUser membership call
                    userName = Convert.ToString(dr("Username"))
                    Try
                        email = Convert.ToString(dr("Email"))
                    Catch
                    End Try
                    Try
                        updatePassword = Convert.ToBoolean(dr("UpdatePassword"))
                    Catch
                    End Try
                    If Not objUserInfo.IsSuperUser Then
                        'For Users the approved/authorised info is stored in UserPortals
                        Try
                            isApproved = Convert.ToBoolean(dr("Authorised"))
                        Catch
                        End Try
                    End If
                End If
            Finally
                If CheckForOpenDataReader And Not dr Is Nothing Then
                    dr.Close()
                End If
            End Try

            If Not objUserInfo Is Nothing Then
                If isHydrated Then
                    ' Get AspNet MembershipUser
                    Dim remoteUser As RemoteSystemUser = GetMembershipUser(userName)

                    'Fill Membership Property
                    FillUserMembership(remoteUser, objUserInfo)
                End If

                objUserInfo.Username = userName
                objUserInfo.Email = email
                objUserInfo.Membership.UpdatePassword = updatePassword
                If Not objUserInfo.IsSuperUser Then
                    'SuperUser authorisation is managed in aspnet Membership
                    objUserInfo.Membership.Approved = isApproved
                End If
            End If

            Return objUserInfo

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Builds a UserMembership object from an AspNet MembershipUser
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="remoteUser">The MembershipUser object to use to fill the DNN UserMembership.</param>
        ''' <history>
        ''' 	[cnurse]	12/10/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub FillUserMembership(ByVal remoteUser As RemoteSystemUser, ByVal user As UserInfo)

            'Fill Membership Property
            If Not remoteUser Is Nothing Then
                user.FirstName = remoteUser.FullName
                user.LastName = ""
                user.DisplayName = remoteUser.FullName
                user.Email = remoteUser.Email
                user.Username = remoteUser.UserName
                user.Membership.CreatedDate = remoteUser.CreationDate
                user.Membership.LastActivityDate = remoteUser.LastActivityDate
                user.Membership.LastLockoutDate = remoteUser.LastLockoutDate
                user.Membership.LastLoginDate = remoteUser.LastLoginDate
                user.Membership.LastPasswordChangeDate = remoteUser.LastPasswordChangedDate
                user.Membership.LockedOut = remoteUser.IsLockedOut
                user.Membership.PasswordQuestion = remoteUser.PasswordQuestion
                user.Membership.ObjectHydrated = True
                user.Membership.Email = remoteUser.Email
                user.Membership.Username = remoteUser.UserName
                user.IsSuperUser = remoteUser.IsSuperUser
                'If user.IsSuperUser Then
                '    'For superusers the Approved info is stored in aspnet membership
                '    user.Membership.Approved = remoteUser.IsApproved
                'End If
            End If

        End Sub


        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' The GetTotalRecords method gets the number of Records returned.
        ''' </summary>
        ''' <param name="dr">An <see cref="IDataReader"/> containing the Total no of records</param>
        ''' <returns>An Integer</returns>
        ''' <history>
        ''' 	[cnurse]	03/30/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function GetTotalRecords(ByRef dr As IDataReader) As Integer

            Dim total As Integer = 0

            If dr.Read Then
                Try
                    total = Convert.ToInt32(dr("TotalRecords"))
                Catch ex As Exception
                    total = -1
                End Try
            End If

            Return total

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetUserByAuthToken retrieves a User from the DataStore using an Authentication Token
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="portalId">The Id of the Portal</param>
        ''' <param name="userToken">The authentication token of the user being retrieved from the Data Store.</param>
        ''' <param name="authType">The type of Authentication Used</param>
        ''' <param name="isHydrated">A flag that determines whether the user is hydrated.</param>
        ''' <returns>The User as a UserInfo object</returns>
        ''' <history>
        '''     [cnurse]	07/09/2007	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function GetUserByAuthToken(ByVal portalId As Integer, ByVal userToken As String, ByVal authType As String, ByVal isHydrated As Boolean) As UserInfo

            Dim dr As IDataReader = dataProvider.GetUserByAuthToken(portalId, userToken, authType)
            Dim objUserInfo As UserInfo = FillUserInfo(portalId, dr, isHydrated, True)

            Return objUserInfo

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' UpdateUserMembership persists a user's Membership to the Data Store
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="user">The user to persist to the Data Store.</param>
        ''' <history>
        '''     [cnurse]	12/13/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub UpdateUserMembership(ByVal user As UserInfo)

            Dim objSecurity As New PortalSecurity
            Dim email As String = objSecurity.InputFilter(user.Email, PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoAngleBrackets Or PortalSecurity.FilterFlag.NoMarkup)

            'Persist the Membership Properties to the AspNet Data Store
            Dim remoteUser As RemoteSystemUser
            remoteUser = RemoteSystemUser.GetUser(user.Username)
            remoteUser.Email = email
            remoteUser.LastActivityDate = Now
            remoteUser.IsApproved = user.Membership.Approved
            RemoteSystemUser.UpdateUser(remoteUser)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Validates the users credentials against the Data Store
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="portalId">The Id of the Portal the user belongs to</param>
        ''' <param name="username">The user name of the User attempting to log in</param>
        ''' <param name="password">The password of the User attempting to log in</param>
        ''' <returns>A Boolean result</returns>
        ''' <history>
        '''     [cnurse]	12/12/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function ValidateUser(ByVal portalId As Integer, ByVal username As String, ByVal password As String) As Boolean
            Return RemoteSystemUser.ValidateUser(username, password)
        End Function

#End Region

#Region "Membership Properties"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets whether the Provider Properties can be edited
        ''' </summary>
        ''' <returns>A Boolean</returns>
        ''' <history>
        '''     [cnurse]	03/02/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides ReadOnly Property CanEditProviderProperties() As Boolean
            Get
                Return False
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the maximum number of invlaid attempts to login are allowed
        ''' </summary>
        ''' <returns>A Boolean.</returns>
        ''' <history>
        '''     [cnurse]	03/02/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Property MaxInvalidPasswordAttempts() As Integer
            Get
                Return 10 ''service.MaxInvalidPasswordAttempts
            End Get
            Set(ByVal Value As Integer)
                Throw New NotSupportedException("Provider properties are hardcoded")
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the Mimimum no of Non AlphNumeric characters required
        ''' </summary>
        ''' <returns>An Integer.</returns>
        ''' <history>
        '''     [cnurse]	02/07/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Property MinNonAlphanumericCharacters() As Integer
            Get
                Return 1
            End Get
            Set(ByVal Value As Integer)
                Throw New NotSupportedException("Provider properties for AspNetMembershipProvider must be set in web.config")
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the Mimimum Password Length
        ''' </summary>
        ''' <returns>An Integer.</returns>
        ''' <history>
        '''     [cnurse]	02/07/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Property MinPasswordLength() As Integer
            Get
                Return 6
            End Get
            Set(ByVal Value As Integer)
                Throw New NotSupportedException("Provider properties for AspNetMembershipProvider must be set in web.config")
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the window in minutes that the maxium attempts are tracked for
        ''' </summary>
        ''' <returns>A Boolean.</returns>
        ''' <history>
        '''     [cnurse]	03/02/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Property PasswordAttemptWindow() As Integer
            Get
                Return 10
            End Get
            Set(ByVal Value As Integer)
                Throw New NotSupportedException("Provider properties for AspNetMembershipProvider must be set in web.config")
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the Password Format as set in the web.config file
        ''' </summary>
        ''' <returns>A PasswordFormat enumeration.</returns>
        ''' <history>
        '''     [cnurse]	02/07/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Property PasswordFormat() As PasswordFormat
            Get
                'Dim stringValue As String = service.PasswordFormat()
                'Dim format As PasswordFormat = [Enum].Parse(PasswordFormat.GetType(), stringValue)

                'Select Case format
                '    Case Web.Security.MembershipPasswordFormat.Clear
                Return PasswordFormat.Clear
                '    Case Web.Security.MembershipPasswordFormat.Encrypted
                'Return PasswordFormat.Encrypted
                '    Case Web.Security.MembershipPasswordFormat.Hashed
                'Return PasswordFormat.Hashed
                'End Select
            End Get
            Set(ByVal Value As PasswordFormat)
                Throw New NotSupportedException("Provider properties for AspNetMembershipProvider must be set in web.config")
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets whether the Users's Password can be reset
        ''' </summary>
        ''' <returns>A Boolean.</returns>
        ''' <history>
        '''     [cnurse]	03/02/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Property PasswordResetEnabled() As Boolean
            Get
                Return False
            End Get
            Set(ByVal Value As Boolean)
                Throw New NotSupportedException("Provider properties for AspNetMembershipProvider must be set in web.config")
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets whether the Users's Password can be retrieved
        ''' </summary>
        ''' <returns>A Boolean.</returns>
        ''' <history>
        '''     [cnurse]	03/02/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Property PasswordRetrievalEnabled() As Boolean
            Get
                Return False
            End Get
            Set(ByVal Value As Boolean)
                Throw New NotSupportedException("Provider properties for AspNetMembershipProvider must be set in web.config")
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets whether a Question/Answer is required for Password retrieval
        ''' </summary>
        ''' <returns>A Boolean.</returns>
        ''' <history>
        '''     [cnurse]	02/07/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Property RequiresQuestionAndAnswer() As Boolean
            Get
                Return System.Web.Security.Membership.RequiresQuestionAndAnswer
            End Get
            Set(ByVal Value As Boolean)
                Throw New NotSupportedException("Provider properties for AspNetMembershipProvider must be set in web.config")
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets a Regular Expression that deermines the strength of the password
        ''' </summary>
        ''' <returns>A String.</returns>
        ''' <history>
        '''     [cnurse]	02/07/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Property PasswordStrengthRegularExpression() As String
            Get
                Return ""
            End Get
            Set(ByVal Value As String)
                Throw New NotSupportedException("Provider properties for AspNetMembershipProvider must be set in web.config")
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets whether a Unique Email is required
        ''' </summary>
        ''' <returns>A Boolean.</returns>
        ''' <history>
        '''     [cnurse]	02/06/2007	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Property RequiresUniqueEmail() As Boolean
            Get
                Return True
            End Get
            Set(ByVal Value As Boolean)
                Throw New NotSupportedException("Provider properties for AspNetMembershipProvider must be set in web.config")
            End Set
        End Property
#End Region

#Region "Membership Methods"


        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets an AspNet MembershipUser from the DataStore
        ''' </summary>
        ''' <param name="user">The user to get from the Data Store.</param>
        ''' <returns>The User as a AspNet MembershipUser object</returns>
        ''' <history>
        '''     [cnurse]	12/10/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function GetMembershipUser(ByVal user As UserInfo) As RemoteSystemUser
            Return GetMembershipUser(user.Username)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets an AspNet MembershipUser from the DataStore
        ''' </summary>
        ''' <param name="userName">The name of the user.</param>
        ''' <returns>The User as a AspNet MembershipUser object</returns>
        ''' <history>
        '''     [cnurse]	04/25/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function GetMembershipUser(ByVal userName As String) As RemoteSystemUser
            Return RemoteSystemUser.GetUser(userName)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ChangePassword attempts to change the users password
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="user">The user to update.</param>
        ''' <param name="oldPassword">The old password.</param>
        ''' <param name="newPassword">The new password.</param>
        ''' <returns>A Boolean indicating success or failure.</returns>
        ''' <history>
        '''     [cnurse]	12/13/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Function ChangePassword(ByVal user As UserInfo, ByVal oldPassword As String, ByVal newPassword As String) As Boolean

            Dim retValue As Boolean = False

            ' Get AspNet MembershipUser
            Dim remoteUser As RemoteSystemUser = GetMembershipUser(user)

            If oldPassword = Null.NullString Then
                'Prevent exception if User is Locked Out - as this option is only calledby an admin user
                'this is safe to do
                remoteUser.UnlockUser()
                oldPassword = remoteUser.GetPassword()
            End If

            retValue = remoteUser.ChangePassword(oldPassword, newPassword)

            If retValue And Me.PasswordRetrievalEnabled Then
                Dim confirmPassword As String = remoteUser.GetPassword()

                If confirmPassword = newPassword Then
                    user.Membership.Password = confirmPassword
                    retValue = True
                Else
                    retValue = False
                End If
            End If

            Return retValue

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ChangePasswordQuestionAndAnswer attempts to change the users password Question
        ''' and PasswordAnswer
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="user">The user to update.</param>
        ''' <param name="password">The password.</param>
        ''' <param name="passwordQuestion">The new password question.</param>
        ''' <param name="passwordAnswer">The new password answer.</param>
        ''' <returns>A Boolean indicating success or failure.</returns>
        ''' <history>
        '''     [cnurse]	02/08/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Function ChangePasswordQuestionAndAnswer(ByVal user As UserInfo, ByVal password As String, ByVal passwordQuestion As String, ByVal passwordAnswer As String) As Boolean

            Dim retValue As Boolean = False

            ' Get AspNet MembershipUser
            Dim remoteUser As RemoteSystemUser = GetMembershipUser(user)

            If password = Null.NullString Then
                password = remoteUser.GetPassword()
            End If

            retValue = remoteUser.ChangePasswordQuestionAndAnswer(password, passwordQuestion, passwordAnswer)

            Return retValue

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' CreateUser persists a User to the Data Store
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="user">The user to persist to the Data Store.</param>
        ''' <returns>A UserCreateStatus enumeration indicating success or reason for failure.</returns>
        ''' <history>
        '''     [cnurse]	12/13/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Function CreateUser(ByRef user As UserInfo) As UserCreateStatus
            Dim createStatus As UserCreateStatus

            Try
                ' check if username exists in database for any portal
                Dim objVerifyUser As UserInfo = GetUserByUserName(Null.NullInteger, user.Username, False)
                If Not objVerifyUser Is Nothing Then
                    If objVerifyUser.IsSuperUser Then
                        ' the username belongs to an existing super user
                        createStatus = UserCreateStatus.UserAlreadyRegistered
                    Else
                        ' the username exists so we should now verify the password
                        If ValidateUser(objVerifyUser.PortalID, user.Username, user.Membership.Password) Then

                            ' check if user exists for the portal specified
                            objVerifyUser = GetUserByUserName(user.PortalID, user.Username, False)
                            If Not objVerifyUser Is Nothing Then
                                ' the user is already registered for this portal
                                createStatus = UserCreateStatus.UserAlreadyRegistered
                            Else
                                ' the user does not exist in this portal - add them
                                createStatus = UserCreateStatus.AddUserToPortal
                            End If
                        Else
                            ' not the same person - prevent registration
                            createStatus = UserCreateStatus.UsernameAlreadyExists
                        End If
                    End If
                Else
                    ' the user does not exist
                    createStatus = UserRegistrationStatus.AddUser
                End If

                'If new user - add to aspnet membership
                If createStatus = UserRegistrationStatus.AddUser Then
                    createStatus = CreateMemberhipUser(user)
                End If

                'If asp user has been successfully created or we are adding a existing user
                'to a new portal 
                If createStatus = UserCreateStatus.Success OrElse createStatus = UserCreateStatus.AddUserToPortal Then
                    'Create the DNN User Record
                    createStatus = CreateDNNUser(user)

                    If createStatus = UserCreateStatus.Success Then
                        'Persist the Profile to the Data Store
                        ProfileController.UpdateUserProfile(user)
                    End If
                End If

            Catch exc As Exception    ' an unexpected error occurred
                'LogException(exc)
                createStatus = UserCreateStatus.UnexpectedError
            End Try

            Return createStatus

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' DeleteUser deletes a single User from the Data Store
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="user">The user to delete from the Data Store.</param>
        ''' <returns>A Boolean indicating success or failure.</returns>
        ''' <history>
        '''     [cnurse]	12/13/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Function DeleteUser(ByVal user As UserInfo) As Boolean

            Dim retValue As Boolean = True
            Dim dr As IDataReader

            Try
                dr = dataProvider.GetRolesByUser(user.UserID, user.PortalID)
                While dr.Read
                    dataProvider.DeleteUserRole(user.UserID, Convert.ToInt32(dr("RoleId")))
                End While
                dr.Close()

                'check if user exists in any other portal
                dr = dataProvider.GetUserByUsername(-1, user.Username)
                dr.Read()
                If Not dr.Read Then
                    dataProvider.DeleteUser(user.UserID)

                    'Delete AspNet MemrshipUser
                    retValue = DeleteMembershipUser(user)
                Else
                    dataProvider.DeleteUserPortal(user.UserID, user.PortalID)
                End If
                dr.Close()
            Catch ex As Exception
                retValue = False
            End Try

            Return retValue

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Deletes all UserOnline inof from the database that has activity outside of the
        ''' time window
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="TimeWindow">Time Window in Minutes</param>
        ''' <history>
        '''     [cnurse]	03/15/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Sub DeleteUsersOnline(ByVal TimeWindow As Integer)

            dataProvider.DeleteUsersOnline(TimeWindow)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Generates a new random password (Length = Minimum Length + 4)
        ''' </summary>
        ''' <returns>A String</returns>
        ''' <history>
        '''     [cnurse]	03/08/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overloads Overrides Function GeneratePassword() As String

            Return GeneratePassword(MinPasswordLength + 4)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Generates a new random password
        ''' </summary>
        ''' <param name="length">The length of password to generate.</param>
        ''' <returns>A String</returns>
        ''' <history>
        '''     [cnurse]	03/08/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overloads Overrides Function GeneratePassword(ByVal length As Integer) As String

            Return "donTuseThis"

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets a collection of Online Users
        ''' </summary>
        ''' <param name="portalId">The Id of the Portal</param>
        ''' <returns>An ArrayList of UserInfo objects</returns>
        ''' <history>
        '''     [cnurse]	03/15/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Function GetOnlineUsers(ByVal PortalId As Integer) As ArrayList

            Dim totalRecords As Integer
            Return FillUserCollection(PortalId, dataProvider.GetOnlineUsers(PortalId), False, totalRecords)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Current Password Information for the User 
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="user">The user to delete from the Data Store.</param>
        ''' <param name="passwordAnswer">The answer to the Password Question, ues to confirm the user
        ''' has the right to obtain the password.</param>
        ''' <returns>A String</returns>
        ''' <history>
        '''     [cnurse]	12/10/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Function GetPassword(ByVal user As UserInfo, ByVal passwordAnswer As String) As String
            Dim retValue As String = ""
            Dim unLocked As Boolean = True

            ' Get AspNet MembershipUser
            Dim remoteUser As RemoteSystemUser = GetMembershipUser(user)

            'Try and unlock user
            If remoteUser.IsLockedOut Then
                unLocked = AutoUnlockUser(remoteUser)
            End If

            If RequiresQuestionAndAnswer Then
                retValue = remoteUser.GetPassword(passwordAnswer)
            Else
                retValue = remoteUser.GetPassword()
            End If

            Return retValue

        End Function

        Public Overrides Function GetUnAuthorizedUsers(ByVal portalId As Integer, ByVal isHydrated As Boolean) As ArrayList

            Return FillUserCollection(portalId, dataProvider.GetUnAuthorizedUsers(portalId), isHydrated)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetUserByUserName retrieves a User from the DataStore
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="portalId">The Id of the Portal</param>
        ''' <param name="userId">The id of the user being retrieved from the Data Store.</param>
        ''' <param name="isHydrated">A flag that determines whether the user is hydrated.</param>
        ''' <returns>The User as a UserInfo object</returns>
        ''' <history>
        '''     [cnurse]	12/10/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Function GetUser(ByVal portalId As Integer, ByVal userId As Integer, ByVal isHydrated As Boolean) As UserInfo

            Dim dr As IDataReader = dataProvider.GetUser(portalId, userId)
            Dim objUserInfo As UserInfo = FillUserInfo(portalId, dr, isHydrated, True)

            Return objUserInfo

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetUserByUserName retrieves a User from the DataStore
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="portalId">The Id of the Portal</param>
        ''' <param name="username">The username of the user being retrieved from the Data Store.</param>
        ''' <param name="isHydrated">A flag that determines whether the user is hydrated.</param>
        ''' <returns>The User as a UserInfo object</returns>
        ''' <history>
        '''     [cnurse]	12/10/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Function GetUserByUserName(ByVal portalId As Integer, ByVal username As String, ByVal isHydrated As Boolean) As UserInfo

            'Dim dr As IDataReader = dataProvider.GetUserByUsername(portalId, username)
            'Dim objUserInfo As UserInfo = FillUserInfo(portalId, dr, isHydrated, True)
            'Dim ru As RemoteSystemUser = 



            'Dim objUserInfo As RemoteSystemUser = RemoteSystemUser.GetUser(username)
            'Dim oU As UserInfo = New UserInfo()
            'oU.PortalID = portalId
            'oU.DisplayName = objUserInfo.FullName
            'Dim st As String = ""
            'oU.Roles = DNNRoleProvider.Instance.GetRoleNames(portalId, System.Configuration.ConfigurationManager.AppSettings("EPPI_ID"))

            'oU.Username = objUserInfo.UserName
            'oU.IsSuperUser = objUserInfo.IsSuperUser
            'Return oU

            Dim mp As AspNetMembershipProvider = New AspNetMembershipProvider()
            'Dim dr As IDataReader = mp.GetUserByUserName(portalId, username, False)
            Dim objUserInfo As UserInfo = DotNetNuke.Security.Membership.AspNetMembershipProvider.Instance.GetUserByUserName(portalId, username, isHydrated)

            Return objUserInfo




        End Function
        Private Function GetEPPIUserByUserName(ByVal portalId As Integer, ByVal username As String, ByVal isHydrated As Boolean) As UserInfo

            'Dim dr As IDataReader = dataProvider.GetUserByUsername(portalId, username)
            'Dim objUserInfo As UserInfo = FillUserInfo(portalId, dr, isHydrated, True)
            'Dim ru As RemoteSystemUser = 



            Dim objUserInfo As RemoteSystemUser = RemoteSystemUser.GetUser(username)
            Dim oU As UserInfo = New UserInfo()
            FillUserMembership(objUserInfo, oU)
            'oU.PortalID = portalId
            'oU.DisplayName = objUserInfo.FullName
            'Dim st As String = ""
            'oU.Roles = DNNRoleProvider.Instance.GetRoleNames(portalId, System.Configuration.ConfigurationManager.AppSettings("EPPI_ID"))

            'oU.Username = objUserInfo.UserName
            'oU.IsSuperUser = objUserInfo.IsSuperUser
            Return oU



        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetUserCountByPortal gets the number of users in the portal
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="portalId">The Id of the Portal</param>
        ''' <returns>The no of users</returns>
        ''' <history>
        '''     [cnurse]	05/01/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Function GetUserCountByPortal(ByVal portalId As Integer) As Integer

            Return dataProvider.GetUserCountByPortal(portalId)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetUserMembership retrieves the UserMembership information from the Data Store
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="user">The user whose Membership information we are retrieving.</param>
        ''' <history>
        '''     [cnurse]	12/13/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Sub GetUserMembership(ByRef user As UserInfo)
            'If user.Username = "template" Then
            '    Return
            'End If

            Dim remoteUser As RemoteSystemUser = Nothing

            'Get remoteUser
            remoteUser = GetMembershipUser(user)

            'Fill Membership Property
            FillUserMembership(remoteUser, user)

            'Get Online Status
            user.Membership.IsOnLine = IsUserOnline(user)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetUsers gets all the users of the portal
        ''' </summary>
        ''' <remarks>If all records are required, (ie no paging) set pageSize = -1</remarks>
        ''' <param name="portalId">The Id of the Portal</param>
        ''' <param name="isHydrated">A flag that determines whether the user is hydrated.</param>
        ''' <param name="pageIndex">The page of records to return.</param>
        ''' <param name="pageSize">The size of the page</param>
        ''' <param name="totalRecords">The total no of records that satisfy the criteria.</param>
        ''' <returns>An ArrayList of UserInfo objects.</returns>
        ''' <history>
        '''     [cnurse]	12/14/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overloads Overrides Function GetUsers(ByVal portalId As Integer, ByVal isHydrated As Boolean, ByVal pageIndex As Integer, ByVal pageSize As Integer, ByRef totalRecords As Integer) As ArrayList

            If pageIndex = -1 Then
                pageIndex = 0
                pageSize = Integer.MaxValue
            End If

            Return FillUserCollection(portalId, dataProvider.GetAllUsers(portalId, pageIndex, pageSize), isHydrated, totalRecords)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetUsersByEmail gets all the users of the portal whose email matches a provided
        ''' filter expression
        ''' </summary>
        ''' <remarks>If all records are required, (ie no paging) set pageSize = -1</remarks>
        ''' <param name="portalId">The Id of the Portal</param>
        ''' <param name="isHydrated">A flag that determines whether the user is hydrated.</param>
        ''' <param name="emailToMatch">The email address to use to find a match.</param>
        ''' <param name="pageIndex">The page of records to return.</param>
        ''' <param name="pageSize">The size of the page</param>
        ''' <param name="totalRecords">The total no of records that satisfy the criteria.</param>
        ''' <returns>An ArrayList of UserInfo objects.</returns>
        ''' <history>
        '''     [cnurse]	12/14/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Function GetUsersByEmail(ByVal portalId As Integer, ByVal isHydrated As Boolean, ByVal emailToMatch As String, ByVal pageIndex As Integer, ByVal pageSize As Integer, ByRef totalRecords As Integer) As ArrayList

            If pageIndex = -1 Then
                pageIndex = 0
                pageSize = Integer.MaxValue
            End If

            Return FillUserCollection(portalId, dataProvider.GetUsersByEmail(portalId, emailToMatch, pageIndex, pageSize), isHydrated, totalRecords)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetUsersByUserName gets all the users of the portal whose username matches a provided
        ''' filter expression
        ''' </summary>
        ''' <remarks>If all records are required, (ie no paging) set pageSize = -1</remarks>
        ''' <param name="portalId">The Id of the Portal</param>
        ''' <param name="isHydrated">A flag that determines whether the user is hydrated.</param>
        ''' <param name="userNameToMatch">The username to use to find a match.</param>
        ''' <param name="pageIndex">The page of records to return.</param>
        ''' <param name="pageSize">The size of the page</param>
        ''' <param name="totalRecords">The total no of records that satisfy the criteria.</param>
        ''' <returns>An ArrayList of UserInfo objects.</returns>
        ''' <history>
        '''     [cnurse]	12/14/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Function GetUsersByUserName(ByVal portalId As Integer, ByVal isHydrated As Boolean, ByVal userNameToMatch As String, ByVal pageIndex As Integer, ByVal pageSize As Integer, ByRef totalRecords As Integer) As ArrayList

            If pageIndex = -1 Then
                pageIndex = 0
                pageSize = Integer.MaxValue
            End If

            Return FillUserCollection(portalId, dataProvider.GetUsersByUsername(portalId, userNameToMatch, pageIndex, pageSize), isHydrated, totalRecords)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetUsersByProfileProperty gets all the users of the portal whose profile matches
        ''' the profile property pased as a parameter
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="portalId">The Id of the Portal</param>
        ''' <param name="isHydrated">A flag that determines whether the user is hydrated.</param>
        ''' <param name="propertyName">The name of the property being matched.</param>
        ''' <param name="propertyValue">The value of the property being matched.</param>
        ''' <param name="pageIndex">The page of records to return.</param>
        ''' <param name="pageSize">The size of the page</param>
        ''' <param name="totalRecords">The total no of records that satisfy the criteria.</param>
        ''' <returns>An ArrayList of UserInfo objects.</returns>
        ''' <history>
        '''     [cnurse]	02/01/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Function GetUsersByProfileProperty(ByVal portalId As Integer, ByVal isHydrated As Boolean, ByVal propertyName As String, ByVal propertyValue As String, ByVal pageIndex As Integer, ByVal pageSize As Integer, ByRef totalRecords As Integer) As ArrayList

            If pageIndex = -1 Then
                pageIndex = 0
                pageSize = Integer.MaxValue
            End If

            Return FillUserCollection(portalId, dataProvider.GetUsersByProfileProperty(portalId, propertyName, propertyValue, pageIndex, pageSize), isHydrated, totalRecords)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets whether the user in question is online
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="user">The user.</param>
        ''' <returns>A Boolean indicating whether the user is online.</returns>
        ''' <history>
        '''     [cnurse]	03/14/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Function IsUserOnline(ByVal user As UserInfo) As Boolean

            Dim isOnline As Boolean = False
            Dim objUsersOnline As New UserOnlineController

            If objUsersOnline.IsEnabled Then
                'First try the Cache
                Dim userList As Hashtable = objUsersOnline.GetUserList()
                Dim onlineUser As OnlineUserInfo = userList(user.UserID.ToString())

                If Not onlineUser Is Nothing Then
                    isOnline = True
                Else
                    'Next try the Database
                    onlineUser = CType(CBO.FillObject(dataProvider.GetOnlineUser(user.UserID), GetType(OnlineUserInfo)), OnlineUserInfo)
                    If Not onlineUser Is Nothing Then
                        isOnline = True
                    End If
                End If
            End If

            Return isOnline

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ResetPassword resets a user's password and returns the newly created password
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="user">The user to update.</param>
        ''' <param name="passwordAnswer">The answer to the user's password Question.</param>
        ''' <returns>The new Password.</returns>
        ''' <history>
        '''     [cnurse]	02/08/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Function ResetPassword(ByVal user As UserInfo, ByVal passwordAnswer As String) As String

            Dim retValue As String = ""

            ' Get AspNet MembershipUser
            Dim remoteUser As RemoteSystemUser = GetMembershipUser(user)

            If RequiresQuestionAndAnswer Then
                retValue = remoteUser.ResetPassword(passwordAnswer)
            Else
                retValue = remoteUser.ResetPassword()
            End If

            Return retValue

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Unlocks the User's Account
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="user">The user whose account is being Unlocked.</param>
        ''' <returns>True if successful, False if unsuccessful.</returns>
        ''' <history>
        '''     [cnurse]	12/13/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Function UnLockUser(ByVal user As UserInfo) As Boolean
            Dim remoteUser As RemoteSystemUser
            remoteUser = RemoteSystemUser.GetUser(user.Username)
            Return remoteUser.UnlockUser()
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' UpdateUser persists a user to the Data Store
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="user">The user to persist to the Data Store.</param>
        ''' <history>
        '''     [cnurse]	12/13/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Sub UpdateUser(ByVal user As UserInfo)

            Dim objSecurity As New PortalSecurity
            Dim firstName As String = objSecurity.InputFilter(user.FirstName, PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoAngleBrackets Or PortalSecurity.FilterFlag.NoMarkup)
            Dim lastName As String = objSecurity.InputFilter(user.LastName, PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoAngleBrackets Or PortalSecurity.FilterFlag.NoMarkup)
            Dim email As String = objSecurity.InputFilter(user.Email, PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoAngleBrackets Or PortalSecurity.FilterFlag.NoMarkup)
            Dim displayName As String = objSecurity.InputFilter(user.DisplayName, PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoAngleBrackets Or PortalSecurity.FilterFlag.NoMarkup)
            Dim updatePassword As Boolean = user.Membership.UpdatePassword
            Dim isApproved As Boolean = user.Membership.Approved

            If displayName = "" Then
                displayName = firstName + " " + lastName
            End If

            'Persist the Membership to the Data Store
            UpdateUserMembership(user)

            'Persist the DNN User to the Database
            dataProvider.UpdateUser(user.UserID, user.PortalID, firstName, lastName, email, displayName, updatePassword, isApproved)

            'Persist the Profile to the Data Store
            ProfileController.UpdateUserProfile(user)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Updates UserOnline info
        ''' time window
        ''' </summary>
        ''' <param name="UserList">List of users to update</param>
        ''' <history>
        '''     [cnurse]	03/15/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Sub UpdateUsersOnline(ByVal UserList As Hashtable)

            dataProvider.UpdateUsersOnline(UserList)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' UserLogin attempts to log the user in, and returns the User if successful
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="portalId">The Id of the Portal the user belongs to</param>
        ''' <param name="username">The user name of the User attempting to log in</param>
        ''' <param name="password">The password of the User attempting to log in</param>
        ''' <param name="VerificationCode">The verification code of the User attempting to log in</param>
        ''' <param name="loginStatus">An enumerated value indicating the login status.</param>
        ''' <returns>The User as a UserInfo object</returns>
        ''' <history>
        '''     [cnurse]	12/10/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Function UserLogin(ByVal portalId As Integer, ByVal username As String, ByVal password As String, ByVal verificationCode As String, ByRef loginStatus As UserLoginStatus) As UserInfo
            Return UserLogin(portalId, username, password, "EPPI", verificationCode, loginStatus)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' UserLogin attempts to log the user in, and returns the User if successful
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="portalId">The Id of the Portal the user belongs to</param>
        ''' <param name="username">The user name of the User attempting to log in</param>
        ''' <param name="password">The password of the User attempting to log in (may not be used by all Auth types)</param>
        ''' <param name="authType">The type of Authentication Used</param>
        ''' <param name="VerificationCode">The verification code of the User attempting to log in</param>
        ''' <param name="loginStatus">An enumerated value indicating the login status.</param>
        ''' <returns>The User as a UserInfo object</returns>
        ''' <history>
        '''     [cnurse]	07/09/2007	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Function UserLogin(ByVal portalId As Integer, ByVal username As String, ByVal password As String, ByVal authType As String, ByVal verificationCode As String, ByRef loginStatus As UserLoginStatus) As UserInfo
            'For now, we are going to ignore the possibility that the User may exist in the 
            'Global Data Store but not in the Local DataStore ie. A shared Global Data Store

            'Initialise Login Status to Failure
            loginStatus = UserLoginStatus.LOGIN_FAILURE

            'Get a light-weight (unhydrated) DNN User from the Database, we will hydrate it later if neccessary
            Dim user As UserInfo = Nothing

            'If authType = "DNN" Then

            'Else
            'user = GetUserByAuthToken(portalId, username, authType, False)
            'End If
            If ValidateUser(Null.NullInteger, username, password) Then
                user = GetUserByUserName(portalId, username, False)
                If user Is Nothing Then
                    user = GetEPPIUserByUserName(portalId, username, False)
                    user.Membership.Approved = True
                    user.Membership.UpdatePassword = False
                    user.PortalID = portalId
                    If user.Email = Nothing Or user.Email = "" Then
                        user.Email = "NOTHING!"
                        Return user
                    End If
                    CreateDNNUser(user)

                    user = GetUserByUserName(portalId, username, False)
                    If Not user Is Nothing Then

                        Dim rI As DotNetNuke.Security.Roles.RoleInfo = DotNetNuke.Security.Roles.RoleProvider.Instance.GetRole(portalId, "Registered Users")
                        Dim urI As UserRoleInfo = New UserRoleInfo()
                        urI.Email = user.Email
                        urI.FullName = user.DisplayName
                        urI.PortalID = portalId
                        urI.RoleID = rI.RoleID
                        urI.RoleGroupID = rI.RoleGroupID
                        urI.RoleName = rI.RoleName
                        urI.UserID = user.UserID
                        DotNetNuke.Security.Roles.RoleProvider.Instance.AddUserToRole(portalId, user, urI)
                    End If
                End If
            End If
            If Not user Is Nothing Then
                'Get AspNet MembershipUser
                Dim remoteUser As DotNetNuke.Security.Membership.RemoteSystemUser = Nothing
                remoteUser = GetMembershipUser(user)
                Dim tRoles(1) As String
                If remoteUser.IsSuperUser Then
                    Array.Resize(tRoles, 2)
                    tRoles(1) = "Administrators"
                End If
                tRoles(0) = "Registered Users"
                user.Roles = tRoles
                'user.UserID = System.Configuration.ConfigurationManager.AppSettings("EPPI_ID")
                Dim boh As Boolean = user.IsInRole("Registered Users")
                Dim rc As DotNetNuke.Security.Roles.RoleController = New DotNetNuke.Security.Roles.RoleController()
                rc.AddUserRole(portalId, user.UserID, 1, DateAndTime.DateAdd(DateInterval.Day, 365, Date.Now()))
                'Dim RolePr As DotNetNuke.Security.Membership.EPPIRoleProvider = New DotNetNuke.Security.Membership.EPPIRoleProvider

                'Fill Membership Property from AspNet MembershipUser
                FillUserMembership(remoteUser, user)

                'Check if the User is Locked Out (and unlock if AutoUnlock has expired)
                If remoteUser.IsLockedOut Then
                    If AutoUnlockUser(remoteUser) Then
                        'Unlock User
                        user.Membership.LockedOut = False

                    Else
                        loginStatus = UserLoginStatus.LOGIN_USERLOCKEDOUT
                    End If

                End If

                'Check in a verified situation whether the user is Approved
                If user.Membership.Approved = False And user.IsSuperUser = False Then
                    'Check Verification code
                    If verificationCode = (portalId.ToString & "-" & user.UserID) Then
                        'Approve User
                        user.Membership.Approved = True

                        'Persist to Data Store
                        UpdateUser(user)
                    Else
                        loginStatus = UserLoginStatus.LOGIN_USERNOTAPPROVED
                    End If
                End If

                'Verify User Credentials
                Dim bValid As Boolean = False
                If loginStatus <> UserLoginStatus.LOGIN_USERLOCKEDOUT And loginStatus <> UserLoginStatus.LOGIN_USERNOTAPPROVED Then
                    If authType = "DNN" Then
                        If user.IsSuperUser Then
                            If ValidateUser(Null.NullInteger, username, password) Then
                                loginStatus = UserLoginStatus.LOGIN_SUPERUSER
                                bValid = True
                            End If
                        Else
                            If ValidateUser(portalId, username, password) Then
                                loginStatus = UserLoginStatus.LOGIN_SUCCESS
                                bValid = True
                            End If
                        End If
                    Else
                        If user.IsSuperUser Then
                            loginStatus = UserLoginStatus.LOGIN_SUPERUSER
                            bValid = True
                        Else
                            loginStatus = UserLoginStatus.LOGIN_SUCCESS
                            bValid = True
                        End If
                    End If
                End If

                If Not bValid Then
                    'Clear the user object
                    user = Nothing
                End If
            End If

            Return user

        End Function

#End Region

#Region "Legacy Support"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' TransferUsersToMembershipProvider transfers legacy users to the
        '''	new ASP.NET MemberRole Architecture
        ''' </summary>
        ''' <history>
        ''' 	[cnurse]	11/6/2004	documented
        '''     [cnurse]    12/15/2005  Moved to MembershipProvider
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Sub TransferUsersToMembershipProvider()
        End Sub

#End Region

        Public Sub New()
            Console.Write("here")
        End Sub
    End Class


End Namespace


Namespace DotNetNuke.Security.Membership

    Public Class RemoteSystemUser

        Private mUserName As String
        Private mFullName As String
        Private mCreationDate As DateTime
        Private mLastActivityDate As DateTime
        Private mLastLockoutDate As DateTime
        Private mLastLoginDate As DateTime
        Private mLastPasswordChangedDate As DateTime
        Private mIsLockedOut As Boolean
        Private mIsSuperUser As Boolean
        Private mID As Integer
        Private mPasswordQuestion As String
        Private mIsApproved As Boolean
        Private mEmail As String

        Public Sub New()

        End Sub

        Public Sub New(ByVal dt As DataTable)
            Me.New()
            Me.UserName = dt.Rows(0)("UserName").ToString()
            Me.ID = dt.Rows(0)("CONTACT_ID")
            Me.CreationDate = dt.Rows(0)("DATE_CREATED") '.ToString()
            If (dt.Rows(0)("LAST_ACTIVITY")).GetType().ToString() <> GetType(DBNull).ToString() Then
                Me.LastActivityDate = dt.Rows(0)("LAST_ACTIVITY") '.ToString()
            Else
                Me.LastActivityDate = Nothing '.ToString()
            End If
            Me.LastLockoutDate = Nothing
            If (dt.Rows(0)("LAST_LOGIN")).GetType().ToString() <> GetType(DBNull).ToString() Then
                Me.LastLoginDate = dt.Rows(0)("LAST_LOGIN") '.ToString()
            Else
                Me.LastLoginDate = Nothing '.ToString()
            End If

            If (dt.Rows(0)("DATE_CREATED")).GetType().ToString() <> GetType(DBNull).ToString() Then
                Me.LastPasswordChangedDate = dt.Rows(0)("DATE_CREATED") '.ToString()
            Else
                Me.LastPasswordChangedDate = Nothing '.ToString()
            End If
            Me.IsLockedOut = False
            Me.PasswordQuestion = ""
            Me.IsApproved = True

            If (dt.Rows(0)("Email")).GetType().ToString() <> GetType(DBNull).ToString() Then
                Me.Email = dt.Rows(0)("Email") '.ToString()
            Else
                Me.Email = Nothing '.ToString()
            End If
            If (dt.Rows(0)("CONTACT_NAME")).GetType().ToString() <> GetType(DBNull).ToString() Then
                Me.FullName = dt.Rows(0)("CONTACT_NAME") '.ToString()
            Else
                Me.FullName = Nothing '.ToString()
            End If


            If (dt.Rows(0)("IS_SITE_ADMIN")).GetType().ToString() <> GetType(DBNull).ToString() Then
                Me.IsSuperUser = dt.Rows(0)("IS_SITE_ADMIN") '.ToString()
            Else
                Me.IsSuperUser = False '.ToString()
            End If
        End Sub

#Region "Properties"

        Public Property UserName() As String
            Get
                Return mUserName
            End Get
            Set(ByVal value As String)
                mUserName = value
            End Set
        End Property
        Public Property FullName() As String
            Get
                Return mFullName
            End Get
            Set(ByVal value As String)
                mFullName = value
            End Set
        End Property

        Public Property CreationDate() As DateTime
            Get
                Return mCreationDate
            End Get
            Set(ByVal value As DateTime)
                mCreationDate = value
            End Set
        End Property

        Public Property LastActivityDate() As DateTime
            Get
                Return mLastActivityDate
            End Get
            Set(ByVal value As DateTime)
                mLastActivityDate = value
            End Set
        End Property

        Public Property LastLockoutDate() As DateTime
            Get
                Return mLastLockoutDate
            End Get
            Set(ByVal value As DateTime)
                mLastLockoutDate = value
            End Set
        End Property

        Public Property LastLoginDate() As DateTime
            Get
                Return mLastLoginDate
            End Get
            Set(ByVal value As DateTime)
                mLastLoginDate = value
            End Set
        End Property

        Public Property LastPasswordChangedDate() As DateTime
            Get
                Return mLastPasswordChangedDate
            End Get
            Set(ByVal value As DateTime)
                mLastPasswordChangedDate = value
            End Set
        End Property

        Public Property IsLockedOut() As Boolean
            Get
                Return mIsLockedOut
            End Get
            Set(ByVal value As Boolean)
                mIsLockedOut = value
            End Set
        End Property
        Public Property IsSuperUser() As Boolean
            Get
                Return mIsSuperUser
            End Get
            Set(ByVal value As Boolean)
                mIsSuperUser = value
            End Set
        End Property
        Public Property ID() As Integer
            Get
                Return mID
            End Get
            Set(ByVal value As Integer)
                mID = value
            End Set
        End Property

        Public Property PasswordQuestion() As String
            Get
                Return mPasswordQuestion
            End Get
            Set(ByVal value As String)
                mPasswordQuestion = value
            End Set
        End Property

        Public Property IsApproved() As Boolean
            Get
                Return mIsApproved
            End Get
            Set(ByVal value As Boolean)
                mIsApproved = value
            End Set
        End Property

        Public Property Email() As String
            Get
                Return mEmail
            End Get
            Set(ByVal value As String)
                mEmail = value
            End Set
        End Property

#End Region

#Region "Shared Methods"
        Public Shared Sub DeleteUser(ByVal userName As String)

            'Dim service As New AuthenticationSite.WebService()
            'service.DeleteUser(userName)

        End Sub

        Public Shared Function GetUser(ByVal userName As String) As RemoteSystemUser
            Dim SQLDBDataReader As SqlClient.SqlDataReader
            Dim SQLDataTable As New DataTable
            Dim SQLCmd As SqlCommand = New SqlCommand()
            Dim SQLCon As New SqlClient.SqlConnection
            SQLCon.ConnectionString = GetConnectionString()
            SQLCon.Open()
            SQLCmd.CommandText = "st_DNNContactDetails"
            SQLCmd.CommandType = CommandType.StoredProcedure
            SQLCmd.Connection = SQLCon
            SQLCmd.Parameters.AddWithValue("USERNAME", userName)
            SQLDBDataReader = SQLCmd.ExecuteReader()
            SQLDataTable.Columns.Add("CONTACT_ID", GetType(Integer), "")
            SQLDataTable.Columns.Add("old_contact_id", GetType(String), "")
            SQLDataTable.Columns.Add("CONTACT_NAME", GetType(String), "")
            SQLDataTable.Columns.Add("USERNAME", GetType(String), "")
            SQLDataTable.Columns.Add("EMAIL", GetType(String), "")
            SQLDataTable.Columns.Add("LAST_LOGIN", GetType(Date), "")
            SQLDataTable.Columns.Add("LAST_ACTIVITY", GetType(Date), "")
            'SQLDataTable.Columns.Add("LAST_RENEWED", GetType(Date), "")
            SQLDataTable.Columns.Add("DATE_CREATED", GetType(Date), "")
            SQLDataTable.Columns.Add("EXPIRY_DATE", GetType(Date), "")
            SQLDataTable.Columns.Add("TYPE", GetType(String), "")
            SQLDataTable.Columns.Add("IS_SITE_ADMIN", GetType(Boolean), "")

            Dim FieldValues(10) As Object 'A Temporary Variable to retrieve all columns in a row and fill them in Object array

            While (SQLDBDataReader.Read)
                SQLDBDataReader.GetValues(FieldValues)
                SQLDataTable.Rows.Add(FieldValues)

            End While
            SQLCon.Close()
            Return New RemoteSystemUser(SQLDataTable)
            'Dim service As New AuthenticationSite.WebService
            'Dim dt As DataTable = service.GetMembershipUser(userName)

            'If Not dt Is Nothing Then
            '    Return New RemoteSystemUser(dt)
            'End If
            'Return Nothing
        End Function
        Public Shared Function GetUser(ByVal userName As String, ByVal password As String) As RemoteSystemUser
            Dim SQLDBDataReader As SqlClient.SqlDataReader
            Dim SQLDataTable As New DataTable
            Dim SQLCmd As SqlCommand = New SqlCommand()
            Dim SQLCon As New SqlClient.SqlConnection
            SQLCon.ConnectionString = GetConnectionString()
            SQLCon.Open()
            SQLCmd.CommandText = "st_ContactLogin"
            SQLCmd.CommandType = CommandType.StoredProcedure
            SQLCmd.Connection = SQLCon
            SQLCmd.Parameters.AddWithValue("USERNAME", userName)
            SQLCmd.Parameters.AddWithValue("PASSWORD", password)
            SQLCmd.Parameters.AddWithValue("IP_ADDRESS", "1.1.1.1")
            SQLDBDataReader = SQLCmd.ExecuteReader()
            SQLDataTable.Columns.Add("USERNAME", GetType(String), "")
            SQLDataTable.Columns.Add("EMAIL", GetType(String), "")

            Dim FieldValues(1) As Object 'A Temporary Variable to retrieve all columns in a row and fill them in Object array

            While (SQLDBDataReader.Read)
                SQLDBDataReader.GetValues(FieldValues)
                SQLDataTable.Rows.Add(FieldValues)

            End While
            SQLCon.Close()
            Return New RemoteSystemUser(SQLDataTable)
            'Dim service As New AuthenticationSite.WebService
            'Dim dt As DataTable = service.GetMembershipUser(userName)

            'If Not dt Is Nothing Then
            '    Return New RemoteSystemUser(dt)
            'End If
            'Return Nothing
        End Function

        Public Shared Function ValidateUser(ByVal username As String, ByVal password As String) As Boolean

            Dim SQLDBDataReader As SqlClient.SqlDataReader
            Dim SQLDataTable As New DataTable
            Dim SQLCmd As SqlCommand = New SqlCommand()
            Dim SQLCon As New SqlClient.SqlConnection
            SQLCon.ConnectionString = GetConnectionString()
            SQLCon.Open()
            SQLCmd.CommandText = "st_ContactLogin"
            SQLCmd.CommandType = CommandType.StoredProcedure
            SQLCmd.Connection = SQLCon
            SQLCmd.Parameters.AddWithValue("USERNAME", username)
            SQLCmd.Parameters.AddWithValue("PASSWORD", password)
            SQLCmd.Parameters.AddWithValue("IP_ADDRESS", "1.1.1.1")
            SQLDBDataReader = SQLCmd.ExecuteReader()
            SQLDataTable.Columns.Add("USERNAME", GetType(String), "")
            SQLDataTable.Columns.Add("EMAIL", GetType(String), "")

            Dim FieldValues(1) As Object 'A Temporary Variable to retrieve all columns in a row and fill them in Object array

            While (SQLDBDataReader.Read)
                SQLDBDataReader.GetValues(FieldValues)
                SQLDataTable.Rows.Add(FieldValues)

            End While
            SQLCon.Close()
            If SQLDataTable Is Nothing Then
                Return False
            Else : Return True
            End If
            'Dim service As New AuthenticationSite.WebService
            'Return service.ValidateUser(username, password)

        End Function

        Public Shared Function CreateUser(ByVal userName As String, ByVal password As String, ByVal email As String, ByVal passwordQuestion As String, ByVal passwordAnswer As String, ByVal isApproved As Boolean, ByRef status As System.Web.Security.MembershipCreateStatus) As RemoteSystemUser

            'Dim service As New AuthenticationSite.WebService
            'Dim returnedStatusString As String = service.CreateUser(userName, password, email, passwordQuestion, passwordAnswer, isApproved)

            'Dim returnedStatus As System.Web.Security.MembershipCreateStatus = [Enum].Parse(GetType(System.Web.Security.MembershipCreateStatus), returnedStatusString)

            'status = returnedStatus
            'If (status = Web.Security.MembershipCreateStatus.Success) Then
            '    Return GetUser(userName)
            'End If
            Return Nothing
        End Function

        Public Shared Sub UpdateUser(ByVal user As RemoteSystemUser)

        End Sub
        Public Shared Function GetConnectionString() As String
            Dim out As String
            Select Case Environment.MachineName.ToLower()
                Case "epi2"
                    out = System.Configuration.ConfigurationManager.ConnectionStrings("EPPIAdm").ToString()
                Case Else
                    out = System.Configuration.ConfigurationManager.ConnectionStrings("EPPIAdmLocal").ToString()
            End Select
            Return out
        End Function
#End Region

#Region "Instance Methods"

        Public Function ResetPassword() As String
            'Dim service As New AuthenticationSite.WebService()
            'Return service.ResetPassword(Me.UserName)
            Return ""
        End Function

        Public Function ResetPassword(ByVal passwordAnswer As String) As String
            'Dim service As New AuthenticationSite.WebService()
            'Return service.ResetPasswordAnswer(Me.UserName, passwordAnswer)
            Return ""
        End Function

        Public Function ChangePassword(ByVal oldPassword As String, ByVal newPassword As String) As Boolean
            'Dim service As New AuthenticationSite.WebService()
            'Return service.ChangePassword(Me.UserName, oldPassword, newPassword)
            Return False
        End Function

        Public Function ChangePasswordQuestionAndAnswer(ByVal password As String, ByVal passwordQuestion As String, ByVal passwordAnswer As String) As Boolean
            'Dim service As New AuthenticationSite.WebService()
            'Return service.ChangePasswordQuestionAndAnswer(Me.UserName, password, passwordQuestion, passwordAnswer)
            Return False
        End Function

        Public Function GetPassword() As String
            'Dim service As New AuthenticationSite.WebService()
            'Return service.GetPassword(Me.UserName)
            Return ""
        End Function

        Public Function UnlockUser() As Boolean
            'Dim service As New AuthenticationSite.WebService()
            'Return service.UnlockUser(Me.UserName)
            Return True
        End Function

#End Region

    End Class

End Namespace
'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2009
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'



Namespace DotNetNuke.Services.Authentication.EPPI

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The AuthenticationConfig class providesa configuration class for the DNN
    ''' Authentication provider
    ''' </summary>
    ''' <history>
    ''' 	[cnurse]	07/10/2007  Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class AuthenticationConfig
        Inherits AuthenticationConfigBase

#Region "Private Members"

        Private _Enabled As Boolean = True
        Private _UseCaptcha As Boolean = Null.NullBoolean

        Private Const CACHEKEY As String = "Authentication.EPPI"

#End Region

#Region "Constructor(s)"

        Protected Sub New(ByVal portalID As Integer)
            MyBase.New(portalID)

            Try
                _Enabled = Boolean.Parse(Convert.ToString(ModuleSettings("DNN_Enabled")))
                _UseCaptcha = Boolean.Parse(Convert.ToString(ModuleSettings("DNN_UseCaptcha")))
            Catch
            End Try
        End Sub

#End Region

#Region "Public Properties"

        Public Property Enabled() As Boolean
            Get
                Return _Enabled
            End Get
            Set(ByVal value As Boolean)
                _Enabled = value
            End Set
        End Property

        Public Property UseCaptcha() As Boolean
            Get
                Return _UseCaptcha
            End Get
            Set(ByVal value As Boolean)
                _UseCaptcha = value
            End Set
        End Property

#End Region

#Region "Public SHared Methods"

        Public Shared Sub ClearConfig(ByVal portalId As Integer)
            Dim key As String = CACHEKEY + "_" + portalId.ToString()
            DataCache.RemoveCache(key)
        End Sub

        Public Shared Function GetConfig(ByVal portalId As Integer) As AuthenticationConfig

            Dim key As String = CACHEKEY + "_" + portalId.ToString()
            Dim config As AuthenticationConfig = CType(DataCache.GetCache(key), AuthenticationConfig)

            If config Is Nothing Then
                config = New AuthenticationConfig(portalId)
                DataCache.SetCache(key, config)
            End If
            Return config
        End Function

        Public Shared Sub UpdateConfig(ByVal config As AuthenticationConfig)
            Dim controller As New ModuleController()

            controller.UpdateModuleSetting(config.AuthenticationModuleID, "DNN_Enabled", config.Enabled.ToString())
            controller.UpdateModuleSetting(config.AuthenticationModuleID, "DNN_UseCaptcha", config.UseCaptcha.ToString())

            ClearConfig(config.PortalID)
        End Sub

#End Region

    End Class

End Namespace
